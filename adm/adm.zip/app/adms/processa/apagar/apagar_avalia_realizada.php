<?php

echo "processa/apagar/apagar_avalia_realizada";

?>