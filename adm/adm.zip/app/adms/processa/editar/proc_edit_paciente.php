<?php
echo "editar paciente"
?>